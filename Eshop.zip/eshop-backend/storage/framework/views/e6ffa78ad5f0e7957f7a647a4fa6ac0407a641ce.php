<!DOCTYPE html>
<html>
<head>
    <title>Order Created</title>
</head>
<body>
    <h1>Order Created</h1>
    <p>
        Dear <?php echo e($customerName); ?>,
    </p>
    <p>
        Thank you for your purchase! Your order #<?php echo e($order->id); ?> has been created successfully.
    </p>
    <?php if(Auth::check()): ?>
    <p>
        You can check your order details by logging into your account or by clicking the following link:
        <a href="http://everydayessentials.tech/orders/<?php echo e($order->id); ?>">View Order</a>
    </p>
    <?php endif; ?>
    <p>
        We will keep you updated on the status of your order.
    </p>
    <p>
        Thank you for your business!
    </p>
    <p>
        Best Regards,
    </p>
    <p>
        Your Store Team
    </p>
</body>
</html><?php /**PATH C:\Users\milos\programy\Programovanie\Web development\Eshop\eshop-backend\resources\views/emails/order/created.blade.php ENDPATH**/ ?>