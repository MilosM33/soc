<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Welcome Email</title>
    </head>
    <body>
        <h1>Welcome to our website!</h1>
        <p>Dear <?php echo e($user->name); ?>,</p>

        <p>
            Thank you for registering with our website. To complete your
            registration, please click the following link to verify your email
            address:
        </p>

        <p><a href="<?php echo e(config('app.WEBSITE_URL')); ?>/my-account/verify/<?php echo e($user->verification_token); ?>">Verify Email Address</a></p>

        <p>Thank you for using our website!</p>

        <p>Best regards,</p>
        <p>The Team</p>
    </body>
</html>
<?php /**PATH C:\Users\milos\programy\Programovanie\Web development\Eshop\eshop-backend\resources\views/emails/user/registered.blade.php ENDPATH**/ ?>