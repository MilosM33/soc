import React from "react";

export default function ProductListingSkeleton() {
  return <h1></h1>;
}
