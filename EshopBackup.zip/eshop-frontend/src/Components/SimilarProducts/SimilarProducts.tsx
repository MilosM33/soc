export default function SimilarProducts({ slug }: { slug: string }) {
  return null;
}