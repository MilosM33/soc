<!DOCTYPE html>
<html>
<head>
    <title>Order Processed</title>
</head>
<body>
    <h1>Order Processed</h1>
    <p>
        Dear <?php echo e($customerName); ?>,
    </p>
    <p>
        We are writing to inform you that your order #<?php echo e($order->id); ?> has been processed.
    </p>
	<p>
		Please give us a few days to deliver your order.
	</p>
    <?php if(Auth::check()): ?>
    <p>
        You can check your order details by logging into your account or by clicking the following link:
        <a href="http://everydayessentials.tech/orders/<?php echo e($order->id); ?>">View Order</a>
    </p>
    <?php endif; ?>
    <p>
        We will keep you updated on the status of your order.
    </p>
    <p>
        Thank you for your business!
    </p>
    <p>
        Best Regards,
    </p>
    <p>
        Your Store Team
    </p>
</body>
</html><?php /**PATH C:\Users\milos\programy\Programovanie\Web development\Eshop\eshop-backend\resources\views/emails/order/processing.blade.php ENDPATH**/ ?>