<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
    <style>
        /* Add some styles for the invoice layout */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
        }
        .invoice-header {
            background-color: #f5f5f5;
            padding: 10px;
        }
        .invoice-header h1 {
            margin: 0;
        }
        .invoice-header p {
            margin: 0;
            font-size: 12px;
        }
        .invoice-body {
            padding: 20px;
        }
        .invoice-body table {
            width: 100%;
            border-collapse: collapse;
        }
        .invoice-body th, .invoice-body td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        .invoice-body th {
            text-align: left;
        }
        .invoice-body .total {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="invoice-header">
        <h1>Invoice</h1>
        <p>Invoice Number: <?php echo e($order->id); ?></p>
        <p>Date: <?php echo e($order->created_at->format('d-m-Y')); ?></p>
    </div>
    <div class="invoice-body">
        <h2>Customer Information</h2>
        <p>Full name: <?php echo e($shippingForm["firstName"] . " " . $shippingForm["lastName"]); ?></p>
        <p>Email: <?php echo e($shippingForm["email"]); ?></p>
        <p>Phone: <?php echo e($shippingForm["phone"]); ?></p>
        <p>Address: <?php echo e($shippingForm["address"]); ?></p>
        <p>City: <?php echo e($shippingForm["city"]); ?></p>
        <p>Appartment: <?php echo e($shippingForm["appartment"]); ?></p>
        <p>Zip: <?php echo e($shippingForm["zip"]); ?></p>
        <p>State: <?php echo e($shippingForm["state"]); ?></p>
        <p>Delivery Method: <?php echo e($shippingForm["deliveryMethod"]); ?></p>


        <h2>Order Information</h2>
        <table>
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Variation</th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->variant_name); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td><?php echo e($item->price); ?> €</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="2" class="total">Total</td>
                    <td class="total">
                        <?php echo e($order->total_price); ?> €
                    </td>
                    <td></td>
                    </tr>
            </tbody>
               
                
               
        </table>
    </div>
                
</body>
</html><?php /**PATH C:\Users\milos\programy\Programovanie\Web development\Eshop\eshop-backend\resources\views/pdfs/orders/invoice.blade.php ENDPATH**/ ?>